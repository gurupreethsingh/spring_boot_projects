package com.ecoders.emp_magement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpMagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpMagementApplication.class, args);
	}

}
