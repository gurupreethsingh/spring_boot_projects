package com.ecoders.emp_magement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpMagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
